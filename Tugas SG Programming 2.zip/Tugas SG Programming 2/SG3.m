x = 1
while x < 10
    disp(x);
    x = x+1;
end