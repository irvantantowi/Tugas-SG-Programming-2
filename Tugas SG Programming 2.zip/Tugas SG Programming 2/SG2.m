A = input('input A : ');
B = input('input B : ');
opr = input('input operator : ', 's');

switch opr
    case '+'
        hasil = A + B;
    case '-'
        hasil = A - B;
    case '/'
        hasil = A / B;
    case '*'
        hasil = A * B;
    otherwise
        disp('input operator salah');
end

disp(hasil);