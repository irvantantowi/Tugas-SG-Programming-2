for i=1:1:30
    disp(i);
end
