angka = input('input suatu angka : ')
if(angka==1)
    disp('input adalah 1');
elseif(angka==4)
    b = angka*2;
    disp(b);
else
    disp('input bukan nol');
end